!function() {
    var EXT65 = new Ext.Version('6.5');
    var EXT66 = new Ext.Version('6.6');
    var CURVER = new Ext.Version(Ext.versions.ext.version);

    var requires = [
        'Ext.data.proxy.Ajax',
        'Ext.dataview.List',
        'Ext.field.Checkbox',
        'Ext.field.DatePicker',
        'Ext.field.Radio',
        'Ext.field.Select',
        'Ext.field.Slider',
        'Ext.field.Spinner',
        'Ext.field.Text',
        'Ext.field.TextArea',
        'Ext.field.Toggle',
        'Ext.form.Panel',
        'Ext.grid.Grid',
        'Ext.grid.cell.Cell',
        'Ext.grid.column.Number',
        'Ext.grid.plugin.ColumnResizing',
        'Ext.grid.plugin.PagingToolbar',
        'Ext.grid.plugin.SummaryRow',
        'Ext.layout.Fit',
        'Ext.layout.VBox',
        'Ext.list.Tree',
        'Ext.slider.Slider',
        'Ext.slider.Thumb',
        'Ext.tab.Panel',
        'Viewer.DummyText',
        'Viewer.model.RowExpanderModel',
        'Viewer.view.list.ListController',
        'Viewer.view.list.ListModel',
        'Viewer.view.tree.TreeModel'
    ];
    if (CURVER.gtEq(EXT66)) {
        requires.push('Ext.field.Time');
    }

Ext.define('Viewer.view.ExampleComponentFactory', {
    requires: requires,

    singleton: true,

    create: function(xtype, uiName) {
        var funcName = this._getFuncName(xtype);
        if(this[funcName]) {
            return this[funcName](uiName);
        }
    },

    createGrid: function(uiName) {
        var config = {
            cls: 'c-preview-root',
            layout: 'fit',
            grouped: true,
            store: {
                model: 'Viewer.model.RowExpanderModel',
                autoLoad: true,
                grouper: {
                    groupFn: function(record) {
                        return record.get('name').charAt(0);
                    }
                },
                proxy: {
                    type: 'ajax',
                    url: 'data/row-expander-data.json',
                    reader: {
                        rootProperty: 'results'
                    }
                }
            },
            plugins: [{
                type: 'gridpagingtoolbar'
            }, {
                type: 'gridsummaryrow'
            }, {
                type: 'gridcolumnresizing'
            }],
            columns: [{
                text: 'Name',
                dataIndex: 'name',
                flex: 3,
                summaryType: 'count',
                resizable: true,
                ui: uiName,
                summaryRenderer: function (value) {
                    return value + ' Companies';
                },
                cell: {
                    xtype: 'gridcell',
                    ui: uiName
                }
            },{
                text: 'Price',
                dataIndex: 'price',
                flex: 1,
                minWidth: 80,
                summaryType: 'average',
                xtype: 'numbercolumn',
                resizable: true,
                format: '0.00',
                ui: uiName,
                cell: {
                    xtype: 'gridcell',
                    ui: uiName
                }
            }],

            itemConfig: {
                ui: uiName,
                header: {
                    ui: uiName
                },
                headerContainer: {
                    ui: uiName
                },
                body: {
                    tpl: new Ext.XTemplate(
                        '<p><b>Change:</b> {change:this.formatChange}</p>',
                        {
                            formatChange: function(v){
                                return '<span>' + Ext.util.Format.usMoney(v) + '</span>';
                            }
                        }
                    )
                }
            }
        };

        // 6.0 Modern, checkcolumn and RowExpander do not exist.
        if(Ext.grid.cell && Ext.grid.cell.Check && Ext.grid.column && Ext.grid.column.Check) {
            config.columns.push({
                xtype: 'checkcolumn',
                dataIndex: "checked",
                width: 50,
                headerCheckbox: true,
                ui: uiName,
                cell: {
                    xtype: 'checkcell',
                    ui: uiName
                }
            });
        }
        if(Ext.grid.plugin.RowExpander) {
            config.plugins.push({
                type: 'rowexpander'
            });
        }

        return Ext.create('Ext.grid.Grid', config);
    },

    createSplitButton: function(uiName) {
        var config = {
            cls: 'c-preview-root',
            layout: {
                type : 'vbox',
                align: 'center'
            },

            bodyPadding: 20,

            defaults: {
                xtype: 'splitbutton',
                margin : '0 0 20 0',
                ui: uiName,
                menu: {
                    items: [{
                        text: 'Menu Item 1'
                    }, {
                        text: 'Menu Item 2'
                    }]
                }
            },

            items : [
                {
                    text: 'Split Button',
                    ui: 'raised'
                },
                {
                    iconCls: 'x-fa fa-home'
                },
                {
                    text: 'With an Icon',
                    iconCls: 'x-fa fa-home'
                },
                {
                    text: 'Disabled',
                    iconCls: 'x-fa fa-cog',
                    disabled: true
                }
            ]
        };

        return Ext.create('Ext.Panel', config);
    },

    createButton: function(uiName) {
        var config = {
            cls: 'c-preview-root',
            layout: {
                type : 'vbox',
                align: 'center'
            },

            bodyPadding: 20,

            defaults: {
                xtype: 'button',
                margin : '0 0 20 0',
                ui: uiName
            },

            items : [
                {
                    text: 'Button'
                },
                {
                    text: 'With an Icon',
                    iconCls: 'x-fa fa-home'
                },
                {
                    text: 'With a Badge',
                    badgeText: '42'
                },
                {
                    text: 'Disabled',
                    iconCls: 'x-fa fa-cog',
                    disabled: true
                }
            ]
        };

    if(CURVER.gtEq(EXT65)) {
            // Add a button with a menu.
            config.items.push({
                text: 'Menu',
                menu: {
                    items: [{
                        text: 'Menu Item 1'
                    }, {
                        text: 'Menu Item 2'
                    }]
                }
            });
        }

        return Ext.create('Ext.Panel', config);
    },

    createFieldsCheckbox: function(uiName) {
        return Ext.create('Ext.form.Panel', {
            cls: 'c-preview-root',
            layout: 'vbox',

            defaults: {
                labelAlign: 'left',
                labelWidth: 100,
                ui: uiName
            },

            bodyPadding: 10,

            items: [{
                xtype: 'checkboxfield',
                checked: true,
                label: 'Checked'
            }, {
                xtype: 'checkboxfield',
                label: 'Unchecked'
            }]
        });
    },

    createFieldsDate: function(uiName) {
        var today = new Date(),
            yesterday = new Date(Date.now() - (24 * 60 * 60 * 1000));

        return Ext.create('Ext.form.Panel', {
            cls: 'c-preview-root',
            layout: {
                type: 'vbox',
                align: 'center'
            },

            defaults: {
                labelAlign: 'left',
                labelWidth: 100
            },

            bodyPadding: 10,

            items: [{
                xtype: 'datepickerfield',
                value: new Date(),
                label : 'Date',
                triggers: {
                    expand: {
                        ui: uiName,
                    }
                }
            }, {
                xtype: 'datepanel',
                margin: '50 0 0 0',
                specialDates: [yesterday],
                disabledDays: [3]
            }]
        })
    },

    createTimePanel: function(uiName) {
        var config = {
            cls: 'c-preview-root',
            layout: {
                type: 'vbox',
                align: 'center'
            },

            bodyPadding: 20,

            defaults: {
                xtype: 'fieldset'
            },
            items: [{
                xtype: 'timefield',
                itemId: '123',
                label: 'Time Field',
                name: 'timeField',
                value: '11:59 PM'
            }]
        };

        return Ext.create('Ext.Panel', config);
    },

    createChip: function(uiName) {
        var config = {
            cls: 'c-preview-root',
            layout: {
                type: 'vbox',
                align: 'center'
            },

            bodyPadding: 20,
            text : 'Test Data',
            closable: true
        };

        return Ext.create('Ext.Chip', config);
    },

    createList: function(uiName) {
        return Ext.create('Ext.Panel', {
            cls: 'c-preview-root',
            layout: 'fit',

            viewModel: {
                type: 'list'
            },

            controller: 'list',

            items: [{
                docked: 'top',
                xtype: 'toolbar',
                items: [{
                    xtype: 'button',
                    text: 'Empty List',
                    handler: 'filterList',
                    scope: 'controller'
                }]
            }, {
                xtype: 'list',
                ui: uiName,
                bind: { store: '{states}' },
                itemTpl: '{description}',
                indexBar: {
                    ui: uiName
                },
                grouped: true,
                title: 'List',
                pinHeaders: true,
                emptyText: 'This list is empty',
                striped: true,
                itemConfig: {
                    ui: uiName,
                    header: {
                        ui: uiName
                    }
                },
                onItemDisclosure: function(record) {
                    Ext.Msg.alert(record.get('description'), record.get('country'), Ext.emptyFn);
                }
            }],
        });
    },

    createDialog: function(uiName) {
        var dialog = Ext.create('Ext.Dialog', {
            cls: 'c-preview-root',

            title: 'Dialog',
            html: Viewer.DummyText.mediumText,
            border: true,
            maximized: true,
            ui: uiName,
            iconCls: 'x-fa fa-globe',

            tools: [
                { type: 'pin' },
                { type: 'refresh' },
                { type: 'search' },
                { type: 'save' }
            ],

            buttons: {
                close: {
                    text: 'Close',
                    handler: function() {
                        dialog.hide();
                    }
                }
            }
        });

        dialog.show();

        return {
            xtype: 'button',
            text: 'Show Dialog',
            handler: function() { 
                dialog.show();
            },
            listeners: {
                destroy: function() {
                    dialog.destroy();
                }
            }
        };
    },

    createPanel: function(uiName) {
        return Ext.create('Ext.Panel', {
            cls: 'c-preview-root',

            flex: 1,
            title: 'Panel',
            html: Viewer.DummyText.mediumText,
            margin: 10,
            border: true,
            iconCls: 'x-fa fa-globe',

            tools: [
                { type:'pin' },
                { type:'refresh' },
                { type:'search', disabled: true },
                { type:'save' }
            ],

            ui: uiName
        });
    },

    createFieldsRadio: function(uiName) {
        return Ext.create('Ext.form.Panel', {
            cls: 'c-preview-root',
            layout: 'vbox',

            defaults: {
                labelAlign: 'left',
                labelWidth: 100,
                ui: uiName
            },

            bodyPadding: 10,

            items: [{
                xtype: 'radiofield',
                label : 'Checked',
                checked: true,
                name: 'radio'
            },  {
                xtype: 'radiofield',
                label : 'Unchecked',
                name: 'radio'
            }]
        })
    },

    createSelectfield: function(uiName) {
        return Ext.create('Ext.form.Panel', {
            cls: 'c-preview-root',
            bodyPadding: 10,

            items: [{
                xtype: 'selectfield',
                label: 'Select',
                triggers: {
                    expand: {
                        ui: uiName,
                    }
                },
                options: [{
                    text: 'First Option',
                    value: 'first'
                },
                {
                    text: 'Second Option',
                    value: 'second'
                },
                {
                    text: 'Third Option',
                    value: 'third'
                }]
            }]
        });
    },

    createSliderfield: function(uiName) {
        var config = {
            cls: 'c-preview-root',

            bodyPadding: 10,

            defaults: {
                minValue: 0,
                value: 50,
                maxValue: 100
            },

            items: [{
                xtype: 'sliderfield',
                ui: uiName,
                label: 'Enabled'
            }, {
                xtype: 'sliderfield',
                ui: uiName,
                label: 'Disabled',
                disabled: true
            }]
        };

        if(CURVER.lt(EXT65)) {
            config.defaults.component = {
                xtype: 'slider',
                ui: uiName,
                thumbDefaults: {
                    xtype: 'thumb',
                    ui: uiName,
                    draggable: {
                        translatable: {
                            easingX: {
                                duration: 300,
                                type: 'ease-out'
                            }
                        }
                    }
                }
            };
        }

        return Ext.create('Ext.form.Panel', config);
    },

    createDisplayfield: function(uiName) {
        return Ext.create('Ext.form.Panel', {
            cls: 'c-preview-root',
            bodyPadding: 10,
            items: [{
                xtype: 'displayfield',
                label: 'Display Field',
                value: 'Displayed Contents',
                ui: uiName
            }]
        });
    },

    createSpinnerfield: function(uiName) {
        return Ext.create('Ext.form.Panel', {
            cls: 'c-preview-root',
            bodyPadding: 10,
            items: [{
                xtype: 'spinnerfield',
                label: 'Spinner',
                minValue: 0,
                maxValue: 100,
                stepValue: 1,
                triggers: {
                    spinup: {
                        ui: uiName
                    },
                    spindown: {
                        ui: uiName
                    }
                }
            }]
        })
    },

    createTabpanel: function(uiName) { 
        var config = {
            cls: 'c-preview-root',
            ui: uiName,

            activeTab: 0,
            tabBar: {
                layout: {
                    pack : 'center',
                    align: 'center'
                },
                docked: 'bottom',
                defaults: {
                    iconAlign: 'top'
                }
            },
            defaults: {
                scrollable: true,
                padding: 10,
                cls: 'card'
            },
            items: [
                {
                    title: 'Plain Tab',
                    html: Viewer.DummyText.mediumText,
                    iconCls: 'x-fa fa-info-circle'
                },
                {
                    title: 'With Badge',
                    html: Viewer.DummyText.mediumText,
                    iconCls: 'x-fa fa-star',
                    badgeText: '4'
                },
                {
                    title: 'Disabled',
                    html: 'Disabled',
                    iconCls: 'x-fa fa-lock',
                    disabled: true
                }, 
            ]
        };

        if(CURVER.gtEq(EXT65)) {
            // Add a menu to the Disabled tab.
            config.items.find(item => item.title === 'Disabled').tab = {
                menu: [{
                    text: 'First item'
                }, {
                    text: 'Second item'
                }]
            };

            // Add a new tab with a Menu.
            config.items.push({
                title: 'Closable',
                closable: true,
                html: Viewer.DummyText.mediumText
            }, {
                title: 'Menu',
                tab: {
                    menu: [{
                        text: 'First item'
                    }, {
                        text: 'Second item'
                    }]
                }
            });
        } else {
            config.tabBar.ui = uiName;
        }

        return Ext.create('Ext.tab.Panel', config);
    },

    createFieldsText: function(uiName) {
        return Ext.create('Ext.Container', {
            cls: 'c-preview-root',

            padding: 10,

            layout: {
                type: 'vbox',
                align: 'stretch'
            },

            defaults: {
                labelAlign: 'left',
                labelWidth: 100,
                ui: uiName
            },

            bodyPadding: 10,

            items: [{
                xtype: 'textfield',
                label : 'Text',
                value: 'value',
                clearIcon: true
            }, {
                xtype: 'textfield',
                label : 'Empty',
                placeHolder: 'placeholder',
                clearIcon: true
            }, {
                xtype: 'searchfield',
                label: 'Search',
                value: 'query'
            }, {
                xtype: 'passwordfield',
                label: 'Password',
                value: 'value',
                revealable: true
            }, {
                xtype: 'textfield',
                label: 'Disabled',
                value: 'Disabled',
                disabled: true
            }, {
                xtype: 'textareafield',
                label : 'Text Area',
                placeHolder: 'enter long text...',
                flex: 1,
                value: Viewer.DummyText.mediumText
            }]
        });
    },

    createTogglefield: function(uiName) {
        return Ext.create('Ext.form.Panel', {
            cls: 'c-preview-root',

            bodyPadding: 10,

            defaults: {
                xtype: 'togglefield',
                labelWidth: 100,
                ui: uiName,
                component: {
                    xtype: 'toggleslider',
                    ui: uiName
                }
            },

            items: [{
                label: 'On',
                value: true
            }, {
                label: 'Off'
            }, {
                label: 'Disabled',
                disabled: true,
                value: true
            }]
        })
    },

    createToolbar: function(uiName) {
        return Ext.create('Ext.Panel', {
            cls: 'c-preview-root',

            items: [{
                xtype: 'toolbar',
                ui: uiName,
                title: 'Horizontal',
                docked: 'top',

                items: [{
                    text: 'One',
                    ui: 'action'
                }, {
                    text: 'Two',
                    ui: 'action'
                }, {
                    xtype: 'spacer'
                }, {
                    xtype: 'component',
                    html: 'Some Text'
                }]
            }, {
                xtype: 'toolbar',
                ui: uiName,
                title: 'Vertical',
                docked: 'left',

                items: [{
                    text: 'One',
                    ui: 'action'
                }, {
                    text: 'Two',
                    ui: 'action'
                }, {
                    xtype: 'spacer'
                }, {
                    xtype: 'component',
                    html: 'Some Text'
                }, {
                    text: 'Forward',
                    ui: 'forward'
                }]
            }]
        });
    },

    createTree: function(uiName) {
        const treelist = Ext.create({
            xtype: 'treelist',
            ui: uiName,
            viewModel: 'tree',
            flex: 1,
            bind: '{navItems}'
        });

        return Ext.create('Ext.Panel', {
            cls: 'c-preview-root',
            bodyPadding: 10,
            scrollable: 'y',

            items: [treelist],

            tbar: [{
                xtype: 'segmentedbutton',
                allowMultiple: true,
                defaults: { ui: 'default-toolbar' },
                items: [{
                    text: 'Nav',
                    hidden: !!uiName,
                    value: 'nav'
                }, {
                    text: 'Micro',
                    value: 'micro'
                }],
                listeners: {
                    change: (segmented, value) => {
                        const navBtn = segmented.query('*[text=Nav]')[0];
                        const hasNav = !uiName && value.indexOf('nav') >= 0;
                        const hasMicro = value.indexOf('micro') >= 0;

                        treelist.setExpanderFirst(!hasNav);
                        treelist.setMicro(hasMicro);
                        if(!uiName) treelist.setUi(hasNav ? 'nav' : null);

                        treelist.setWidth(hasMicro ? treelist.toolsElement.getWidth() : null);
                        navBtn.setDisabled(hasMicro);
                    }
                }
            }]
        });
    },

    createTitlebar: function(uiName) {
        return Ext.create('Ext.Panel', {
            cls: 'c-preview-root',
            items: [{
                xtype: 'titlebar',
                docked: 'top',
                title: 'Navigation',
                ui: uiName,
                items: [
                    {
                        iconCls: 'x-fa fa-home',
                        align: 'left'
                    },
                    {
                        iconCls: 'x-fa fa-plus',
                        align: 'right'
                    }
                ]
            }]
        })
    },

    createFormpanel: function(uiName) {
        return Ext.create('Ext.form.Panel', {
            cls: 'c-preview-root',

            bodyPadding: 10,

            defaults: {
                labelWidth: 135
            },

            items: [{
                xtype: 'textfield',
                label: 'Field w/Value',
                value: 'value',
                ui: uiName
            }, {
                xtype: 'textfield',
                label: 'Empty Field',
                placeHolder: 'placeholder',
                ui: uiName
            }, {
                xtype: 'textfield',
                disabled: true,
                value: 'disabled',
                label: 'Disabled',
                ui: uiName
            }, {
                xtype: 'textfield',
                required: true,
                label: 'Required',
                ui: uiName
            }, {
                xtype: 'textfield',
                required: true,
                errorMessage: 'Invalid field.',
                label: 'Invalid',
                value: 'invalid',
                component: {
                    pattern: 'valid'
                },
                ui: uiName
            }, {
                xtype: 'textfield',
                required: true,
                errorMessage: 'Invalid field.',
                label: 'Invalid (side)',
                value: 'invalid (side)',
                errorTarget: 'side',
                ui: uiName
            }, {
                xtype: 'textfield',
                required: true,
                errorMessage: 'Invalid field.',
                label: 'Invalid (under)',
                value: 'invalid (under)',
                errorTarget: 'under',
                ui: uiName
            }]
        })
    },

    createCarousel: function(uiName) {
        return Ext.create('Ext.carousel.Carousel', {
            cls: 'c-preview-root',
            ui: uiName,
            items: [{
                layout: {
                    type: 'vbox',
                    align: 'center',
                    pack: 'center'
                },
                items: {
                    html : 'Item 1'
                }
            },
            {
                layout: {
                    type: 'vbox',
                    align: 'center',
                    pack: 'center'
                },
                items: {
                    html : 'Item 2'
                }
            },
            {
                layout: {
                    type: 'vbox',
                    align: 'center',
                    pack: 'center'
                },
                items: {
                    html : 'Item 3'
                }
            }]
        });
    },

    createMenu: function(uiName) {
        return Ext.create('Ext.Container', {
            cls: 'c-preview-root',
            layout: 'center',

            items: {
                xtype: 'menu',
                ui: uiName,
                showSeparator: true,
                floated: false,
                width: 240,
                listeners: {
                    // Do not allow the menu to be hidden when things are selected (or ever).
                    beforehide: function() { return false; }
                },
                items: [{
                    text: 'Where is my cloud?',
                    iconCls: 'x-fa fa-cloud'
                }, {
                    text: 'Download',
                    iconCls: 'x-fa fa-cloud-download'
                }, {
                    text: 'Upload',
                    iconCls: 'x-fa fa-cloud-upload'
                }, {
                    xtype: 'menucheckitem',
                    text: 'I love clouds!'
                }, {
                    text: 'Disabled',
                    iconCls: 'x-fa fa-cloud',
                    disabled: true
                }]
            }
        });
    },

    createTooltip: function(uiName) {
        var tooltip,
            panel = Ext.create('Ext.Panel', {
                padding: 20,
                layout: 'fit',
                cls: 'c-preview-root'
            });

        panel.on({
            painted: function(target) {
                tooltip = Ext.create('Ext.tip.ToolTip', {
                    ui: uiName,
                    html: 'This is a tooltip.',
                    title: 'Title',
                    tools: [{
                        type: 'refresh'
                    }, {
                        type: 'help'
                    }, {
                        type: 'close'
                    }],
                    closable: false,
                    dismissDelay: 0,
                    showDelay: 0,
                    hideDelay: 0,
                    width: 200,
                    anchor: true,
                    anchorToTarget: panel,
                    listeners: {
                        beforehiddenchange: function(tooltip, hidden) {
                            return !hidden;  
                        },
                        painted: function(target) {
                            tooltip.element.setXY([ target.getX() - tooltip.element.getWidth() / 2, 20 ]);
                        }
                    }
                });
                
                tooltip.showBy(target);
            },
            destroy: function() {
                tooltip.destroy();
            }
        });

        return panel;
    },

    /**
     * Gets the factory function name based on an xtype.
     *
     * Example:
     * 'fields-spinner' => 'createFieldsSpinner'
     * 'toolbar' => 'createToolbar'
     *
     * @param xtype
     * @returns {string}
     * @private
     */
    _getFuncName: function(xtype) {
        return 'create' + xtype.substring(0,1).toUpperCase() +
            xtype.substring(1)
                .replace(/-(.)/g, function(m, p1) { return p1.toUpperCase() });
    },
});
}();
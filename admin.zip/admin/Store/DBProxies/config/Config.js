Ext.define('DBProxies.config.Config', {
    singleton: true,
    dbName: 'EmdadSangin',
    dbDescription: 'EmdadSangin',
    dbVersion: '1.0',
    dbSize: 5000000
    
});

// Keys for the responsiveConfig prop.  

export const medium = "width < 992";
export const large = "width > 992";
/////////

var Config = {
    title : "مدیریت چمرانی ها",
    _socketUrl: "https://chamran.sitenevis.com/socket"
};
window.document.title = Config.title
export default Config;


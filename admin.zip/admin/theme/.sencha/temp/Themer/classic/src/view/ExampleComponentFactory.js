/**
 * Created by dan on 12/13/16.
 */
Ext.define('Viewer.view.ExampleComponentFactory', {
    requires: [
        'Ext.button.Button',
        'Ext.button.Split',
        'Ext.container.ButtonGroup',
        'Ext.container.Container',
        'Ext.form.FieldSet',
        'Ext.form.FieldSet',
        'Ext.form.Panel',
        'Ext.form.field.Checkbox',
        'Ext.form.field.ComboBox',
        'Ext.form.field.Display',
        'Ext.form.field.Radio',
        'Ext.form.field.Tag',
        'Ext.form.field.Text',
        'Ext.form.field.TextArea',
        'Ext.layout.container.Anchor',
        'Ext.layout.container.Center',
        'Ext.layout.container.Column',
        'Ext.layout.container.HBox',
        'Ext.layout.container.VBox',
        'Ext.menu.CheckItem',
        'Ext.menu.Menu',
        'Ext.panel.Panel',
        'Ext.tab.Panel',
        'Ext.tip.ToolTip',
        'Ext.toolbar.Breadcrumb',
        'Ext.toolbar.Separator',
        'Ext.toolbar.TextItem',
        'Ext.toolbar.Toolbar',
        'Ext.window.Window',
        'Viewer.DummyText',
        'Viewer.store.BreadCrumbStore'
    ],

    singleton: true,

    create: function(xtype, uiName) {
        var funcName = this._getFuncName(xtype);
        if(this[funcName]) {
            return this[funcName](uiName);
        }
    },

    createBasicPanels: function(uiName) {
        var config = {
            xtype: 'container',
            cls: 'c-preview-root',
            defaults: {
                xtype: 'panel',
                width: 450,
                height: 200,
                bodyPadding: 10,
                collapsible: true,
                html: Viewer.DummyText.mediumText,
                margin: '0 0 10 0',
                tools: [
                    { type:'pin' },
                    { type:'refresh' },
                    { type:'search' },
                    { type:'save' }
                ]
            },

            items: [{
                title: 'Bordered Panel',
                glyph: 'xf140@FontAwesome',
                border: true
            }]
        };

        if(uiName) {
            config.defaults.ui = uiName;
        }

        return Ext.create(config);
    },

    createBreadCrumbToolbar: function(uiName) {
        this.breadcrumbstore = this.breadcrumbstore || Ext.create('Viewer.store.BreadCrumbStore');
        this.breadcrumbselection = this.breadcrumbselection || this.breadcrumbstore.findNode('text', 'DragZone.js');
        var config = {
            xtype: 'container',
            cls: 'c-preview-root',
            defaults: {
                width: 500,
                height: 250,
                bodyPadding: 10,
                margin: '0 0 10 0'
            },

            items: [{
                title: 'Breadcrumb',
                glyph: 'xf085@FontAwesome',
                xtype: 'panel',
                tbar: [{
                    xtype: 'breadcrumb',
                    store: this.breadcrumbstore,
                    showIcons: true,
                    useSplitButtons: false,
                    selection: this.breadcrumbselection
                }]
            }, {
                title: 'Breadcrumb w/Split Buttons',
                glyph: 'xf085@FontAwesome',
                xtype: 'panel',
                tbar: [
                    {
                        xtype: 'breadcrumb',
                        store: this.breadcrumbstore,
                        showIcons: true,
                        useSplitButtons: true,
                        selection: this.breadcrumbselection
                    }
                ]
            }]
        };

        if(uiName) {
            config.items.forEach(function(i) { i.tbar[0].ui = uiName; });
        }

        return Ext.create(config);
    },

    createFormTextField: function(uiName) {
        var config = {
            xtype: 'form',
            cls: 'c-preview-root',
            bodyPadding: '20 20 10 20',

            defaults: {
                labelAlign: 'right',
                labelWidth: 100,
                msgTarget : 'under'
            },

            items: [{
                xtype: 'textfield',
                fieldLabel : 'Text Field',
                vtype : 'email',
                qtip: 'Enter an invalid email address to adjust invalid styles',
                emptyText : 'user@domain.com'
            }, {
                xtype: 'textarea',
                fieldLabel : 'Text Area',
                emptyText: 'Text goes here...'
            }, {
                xtype: 'combo',
                fieldLabel: 'Dropdown',
                displayField: 'state',
                store: 'states',
                emptyText: 'Select a state...',
                queryMode: 'local',
                typeAhead: true
            }]
        };

        if(uiName) {
            config.defaults.ui = uiName;
        }

        return Ext.create(config);
    },

    createFormDisplayField: function(uiName) {
        var config = {
            xtype: 'form',
            cls: 'c-preview-root',
            bodyPadding: '20 20 10 20',
            items: {
                xtype: 'displayfield',
                value: 'value'
            }
        };

        if(uiName) {
            config.items.ui = uiName;
        }

        return Ext.create(config);
    },

    createFormFieldset: function(uiName) {
        var config = {
            xtype: 'form',
            cls: 'c-preview-root',
            bodyPadding: '10 20 10 20',

            width : 500,
            layout : 'anchor',

            items: [{
                xtype:'fieldset',
                title: 'Fieldset',
                collapsible: true,
                layout: 'anchor',
                defaultType: 'textfield',
                defaults: { labelWidth: 60 },
                items: [{
                    fieldLabel: 'Field 1'
                }, {
                    fieldLabel: 'Field 2'
                }]
            }, {
                xtype:'fieldset',
                title: 'Fieldset',
                checkboxToggle: true,
                layout: 'anchor',
                defaultType: 'textfield',
                defaults: { labelWidth: 60 },
                items: [{
                    fieldLabel: 'Field 1'
                }, {
                    fieldLabel: 'Field 2'
                }]
            }]
        };

        if(uiName) {
            config.defaults = {ui: uiName};
        }

        return Ext.create(config);
    },

    createFormTagfield: function(uiName) {
        var config = {
            xtype: 'form',
            cls: 'c-preview-root',
            bodyPadding: '20 20 10 20',

            items: {
                xtype: 'tagfield',
                store: 'states',
                width: 400,
                value: ['CA'],
                reference: 'states',
                displayField: 'state',
                valueField: 'state',
                filterPickList: true,
                queryMode: 'local'
            }
        };

        if(uiName) {
            config.defaults = {ui: uiName};
        }

        return Ext.create(config);
    },

    createFormCheckboxRadio: function(uiName) {
        var config = {
            xtype: 'form',
            cls: 'c-preview-root',
            bodyPadding: '20 20 10 20',

            layout: 'vbox',
            items: [{
                xtype: 'container',
                layout: 'hbox',
                defaults: {
                    xtype: 'checkbox',
                    margin: '0 10'
                },
                items: [{
                    boxLabel: 'Checkbox'
                }]
            }, {
                xtype: 'container',
                layout: 'hbox',
                defaults: {
                    xtype: 'radio',
                    margin: '0 10'
                },
                items: [{
                    checked: true,
                    boxLabel: 'Radio 1',
                    name: 'radio',
                    inputValue: 'red'
                }, {
                    boxLabel: 'Radio 2',
                    name: 'radio',
                    inputValue: 'blue'
                }]
            }]
        };

        if(uiName) {
            config.items.forEach(function(i) {
                i.defaults.ui = uiName;
            });
        }

        return Ext.create(config);
    },

    createBasicTabs: function(uiName) {
        var config = {
            xtype: 'tabpanel',
            cls: 'c-preview-root',

            defaults: {
                width: 475,
                height: 200,
                bodyPadding: 10,
                html: Viewer.DummyText.mediumText
            },

            items: [{
                title : 'Just Text'
            }, {
                title : 'Icon Tab',
                glyph : 'xf087@FontAwesome'
            }, {
                title : 'Closable Tab',
                closable: true
            },  {
                title : 'Disabled Tab',
                disabled : true,
                glyph : 'xf013@FontAwesome'
            }]
        };

        if(uiName) {
            config.tabBar = { ui: uiName };
            config.defaults.tabConfig = { ui: uiName };
        }

        return Ext.create(config);
    },

    createPlainTabs: function(uiName) {
        var config = {
            xtype: 'tabpanel',
            cls: 'c-preview-root',
            defaults: {
                width: 475,
                height: 200,
                bodyPadding: 10,
                html: Viewer.DummyText.mediumText
            },
            plain: true,
            items: [{
                title : 'Just Text'
            }, {
                title : 'Icon Tab',
                glyph : 'xf087@FontAwesome'
            }, {
                title : 'Closable Tab',
                closable: true
            },  {
                title : 'Disabled Tab',
                disabled : true,
                glyph : 'xf013@FontAwesome'
            }]
        };

        if(uiName) {
            config.defaults.tabConfig = { ui: uiName };
        }

        return Ext.create(config);
    },

    createBasicWindow: function(uiName) {
        var config = {
            xtype: 'window',
            cls: 'c-preview-root',
            height: 300,
            width: 400,
            title: 'Window',
            scrollable: true,
            bodyPadding: 10,
            html: Viewer.DummyText.mediumText,
            constrain: true,
            closable: false,
            hidden : false,
            floating : false,
            iconCls : 'fa fa-binoculars',
            tools : [{
                type : 'close'
            }],
            bbar : [{
                text : 'Message Box',
                handler : function () {
                    Ext.Msg.show({
                        title : 'Alert!',
                        message : 'Hi! I am just an alert!',
                        buttons : Ext.Msg.YESNO,
                        icon : Ext.Msg.INFO
                    })
                }
            }]
        };

        if(uiName) {
            config.ui = uiName;
        }

        return Ext.create(config);
    },

    createTooltip: function(uiName) {
        var tooltip;

        var config = {
            xtype: 'panel',
            cls: 'c-preview-root',
            layout: 'center',

            items: {
                xtype: 'panel',
                listeners: {
                    afterrender: {
                        single: true,
                        fn: function(target) {
                            var tooltipConfig = {
                                xtype: 'tooltip',
                                html: '<div style="white-space: nowrap">This is a tooltip <a href="#">with a link</a>.</div>',
                                title: 'Title',
                                tools: [{ type: 'refresh' }, { type: 'help' }, { type: 'close' }],
                                closable: false,
                                listeners: {
                                    beforehide: function() {
                                        return false;
                                    },
                                    afterlayout: function() {
                                        tooltip.setXY([ target.getX() - tooltip.getWidth() / 2, target.getY() ]);
                                    } 
                                }
                            };

                            if (uiName) tooltipConfig.ui = uiName;
                            tooltip = Ext.create(tooltipConfig);
                            tooltip.show(target.getEl());
                        }
                    },

                    afterlayout: function() {
                        if (tooltip) tooltip.updateLayout();
                    },

                    destroy: function() {
                        tooltip.destroy()
                    }
                }
            }
        };

        return Ext.create(config);
    },

    createBasicMenu: function(uiName) {
        var config = {
            xtype: 'menu',
            cls: 'c-preview-root',
            floating : false,
            width : 180,
            margin: '0 0 10 0',
            showSeparator : true,
            items: [{
                text: 'Where is my cloud?',
                iconCls : 'x-fa fa-cloud'
            },{
                text: 'Download',
                iconCls : 'x-fa fa-cloud-download'
            },{
                text: 'Upload',
                iconCls : 'x-fa fa-cloud-upload'
            },{
                xtype : 'menucheckitem',
                text : 'I love clouds!'
            }]
        };

        if(uiName) {
            config.ui = uiName;
        }

        return Ext.create(config);
    },

    createProgressbar: function(uiName) {
        var config = {
            xtype: 'container',
            cls: 'c-preview-root',
            html : '<div id="progress-div"></div>',
            items : [
                {
                    xtype : 'progressbar',
                    renderTo : Ext.get('progress-div'),
                    width : 300,
                    listeners : {
                        render : function (pb) {
                            pb.wait({
                                interval : 500,
                                increment : 15,
                                text : 'Updating...',
                                scope : pb
                            })
                        }
                    }
                }
            ]
        };

        if(uiName) {
            config.defaults = { ui: uiName };
        }

        return Ext.create(config);
    },

    createBasicButtons: function(uiName) {
        var config = {
            xtype: 'container',
            cls: 'c-preview-root',
            defaults : {
                xtype: 'button',
                margin : '0 0 20 0'
            },

            layout : {
                type : 'vbox',
                align: 'center'
            },

            items : [
                {
                    text : 'Small'
                },
                {
                    text: 'Small Disabled',
                    disabled: true
                },
                {
                    text : 'Small',
                    glyph : 'xf087@FontAwesome'
                },
                {
                    text : 'Medium',
                    scale : 'medium'
                },
                {
                    text: 'Medium Disabled',
                    scale: 'medium',
                    disabled: true
                },
                {
                    text : 'Medium',
                    glyph : 'xf087@FontAwesome',
                    scale : 'medium'
                },
                {
                    text : 'Large',
                    scale : 'large'
                },
                {
                    text: 'Large Disabled',
                    scale: 'large',
                    disabled: true
                },
                {
                    text : 'Large',
                    glyph : 'xf087@FontAwesome',
                    scale : 'large'
                }
            ]
        };

        if(uiName) {
            config.defaults.ui = uiName;
        }

        return Ext.create(config);
    },

    createButtonGroup: function(uiName) {
        var config = {
            xtype: 'panel',
            cls: 'c-preview-root',
            bodyPadding: 20,

            layout: 'hbox',

            items: [{
                xtype: 'buttongroup',
                frame : false,
                columns: 3,
                title: 'No Frame',
                items: [{
                    text: 'Button 1'
                }, {
                    text: 'Button 2'
                }, {
                    text: 'Button 3'
                }]
            }, {
                xtype: 'buttongroup',
                frame : true,
                columns: 3,
                title: 'Frame',
                margin: '0 20',
                items: [{
                    text: 'Button 1'
                }, {
                    text: 'Button 2'
                }, {
                    text: 'Button 3'
                }]
            }]
        };

        if(uiName) {
            config.defaults = { ui: uiName };
        }

        return Ext.create(config);
    },

    createBasicToolbar: function(uiName) {
        var config = {
            xtype: 'container',
            cls: 'c-preview-root',

            items: [{
                xtype: 'panel',
                width: 600,
                height: 250,
                bodyPadding: 10,
                margin: '0 0 10 0',
                title: 'Horizontal Toolbar',
                glyph: 'xf085@FontAwesome',
                border: true,
                dockedItems: [{
                    xtype: 'toolbar',
                    dock: 'top',
                    items: [{
                        xtype:'splitbutton',
                        text:'Menu Button',
                        iconCls: null,
                        glyph: 'xf0ca@FontAwesome',
                        menu:[{
                            text:'Menu Button 1'
                        }]
                    }, '-', {
                        xtype:'splitbutton',
                        text:'Cut',
                        iconCls: null,
                        glyph: 'xf0c4@FontAwesome',
                        menu: [{
                            text:'Cut Menu Item'
                        }]
                    }, {
                        iconCls: null,
                        glyph: 'xf0c5@FontAwesome',
                        text:'Copy',
                        disabled: true
                    }, {
                        text:'Paste',
                        iconCls: null,
                        glyph: 'xf0ea@FontAwesome',
                        menu:[{
                            text:'Paste Menu Item'
                        }]
                    }, {
                        glyph: 'xf032@FontAwesome',
                        text: 'Bold',
                        enableToggle: true
                    }, {
                        xtype: 'tbtext',
                        text: 'Text'
                    }]
                }]
            },
            {
                xtype: 'panel',
                width: 600,
                height: 250,
                bodyPadding: 10,
                margin: '0 0 10 0',
                title: 'Vertical Toolbar',
                glyph: 'xf085@FontAwesome',
                border: true,
                dockedItems: [{
                    xtype: 'toolbar',
                    dock: 'left',
                    items: [{
                        xtype:'splitbutton',
                        text:'Menu Button',
                        iconCls: null,
                        glyph: 'xf0ca@FontAwesome',
                        menu:[{
                            text:'Menu Button 1'
                        }]
                    }, '-', {
                        xtype:'splitbutton',
                        text:'Cut',
                        iconCls: null,
                        glyph: 'xf0c4@FontAwesome',
                        menu: [{
                            text:'Cut Menu Item'
                        }]
                    }, {
                        iconCls: null,
                        glyph: 'xf0c5@FontAwesome',
                        text:'Copy',
                        disabled: true
                    }, {
                        text:'Paste',
                        iconCls: null,
                        glyph: 'xf0ea@FontAwesome',
                        menu:[{
                            text:'Paste Menu Item'
                        }]
                    }, {
                        glyph: 'xf032@FontAwesome',
                        text: 'Bold',
                        enableToggle: true
                    }, {
                        xtype: 'tbtext',
                        text: 'Text'
                    }]
                }]
            }]
        };

        if(uiName) {
            config.items.forEach(function(panel) {
                panel.dockedItems.forEach(function(dockedItem) {
                    dockedItem.items.forEach(function(btn) {
                        if(Ext.isObject(btn) && (!btn.xtype || btn.xtype === 'splitbutton' || btn.xtype === 'button')) {
                            btn.ui = uiName + '-toolbar';
                        }
                    });

                    dockedItem.ui = uiName;
                });
            });
        }

        return Ext.create(config);
    },

    createTreeList: function(uiName) {
        var treeList = Ext.create({
            xtype: 'treelist',
            ui: uiName,
            viewModel: 'tree-list',
            width: 300,
            height: 450,
            bind: '{treeNavItems}'
        });

        return Ext.create('Ext.Panel', {
            cls: 'c-preview-root',
            layout: {
                type: 'vbox',
                align: 'stretch'
            },
            items: [
                {
                    xtype: 'container',
                    layout: {
                        type: 'hbox',
                        pack: 'center'
                    },
                    items: [{
                        xtype: 'radiofield',
                        name: 'micro',
                        boxLabel: 'Full',
                        checked: true,
                        margin: '0 15 0 0'
                    }, {
                        xtype: 'radiofield',
                        name: 'micro',
                        boxLabel: 'Micro',
                        listeners: {
                            change: function(radio, micro) {
                                treeList.setMicro(micro);
                            }
                        }
                    }],
                }, 
                treeList
            ]
        });


        // var treeList = Ext.create({
        //     xtype: 'treelist',
        //     viewModel: 'tree-list',
        //     ui: uiName,
        //     width: 300,
        //     height: 450,
        //     margin: '0 40 0 0',
        //     bind: '{treeNavItems}'
        // });

        // return Ext.create({
        //     xtype: 'container',
        //     renderTo: Ext.getBody(),
        //     layout: {
        //         type: 'vbox',
        //         align: 'center'
        //     },
        //     items: [
        //         {
        //             xtype: 'button',
        //             enableToggle: true,
        //             text: 'micro: false',
        //             margin: '0 0 20 0',
        //             toggleHandler: function(button, micro) {
        //                 treeList.setMicro(micro);
        //                 button.setText('micro: ' + micro);
        //             }
        //         }, 
        //         treeList
        //     ]
        // });
    },

    /**
     * Gets the factory function name based on an xtype.
     *
     * Example:
     * 'fields-spinner' => 'createFieldsSpinner'
     * 'toolbar' => 'createToolbar'
     *
     * @param xtype
     * @returns {string}
     * @private
     */
    _getFuncName: function(xtype) {
        return 'create' + xtype.substring(0,1).toUpperCase() +
            xtype.substring(1)
                .replace(/-(.)/g, function(m, p1) { return p1.toUpperCase() });
    },
});
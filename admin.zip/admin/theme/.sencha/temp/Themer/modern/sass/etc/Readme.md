### ./sass/etc

This folder contains misc. support code for Sass builds when using the modern toolkit (global functions, etc.).
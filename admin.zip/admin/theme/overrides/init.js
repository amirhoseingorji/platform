Ext.namespace('Ext.theme.is')['custom-ext-react-theme'] = true;
Ext.theme.name = 'custom-ext-react-theme';
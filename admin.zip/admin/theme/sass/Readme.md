# custom-ext-react-theme/sass

This folder contains SASS files of various kinds, organized in sub-folders:

    custom-ext-react-theme/sass/etc
    custom-ext-react-theme/sass/src
    custom-ext-react-theme/sass/var

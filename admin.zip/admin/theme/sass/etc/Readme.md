# custom-ext-react-theme/sass/etc

This folder contains miscellaneous SASS files. Unlike `"custom-ext-react-theme/sass/etc"`, these files
need to be used explicitly.
